/*

	Name:	Indra Bhurtel
	ID:	1001542825

*/


#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define ALIGN4(s) (((((s)-1) >> 2) << 2) + 4)
#define BLOCK_DATA(b) ((b) + 1)
#define BLOCK_HEADER(ptr) ((struct block *)(ptr)-1)

static int atexit_registered = 0;
static int num_mallocs = 0;
static int num_reallocs = 0;
static int num_callocs = 0;
static int num_frees = 0;
static int num_reuses = 0;
static int num_grows = 0;
static int num_splits = 0;
static int num_coalesces = 0;
static int num_blocks = 0;
static int num_requested = 0;
static int max_heap = 0;

/*
 *  \brief printStatistics
 *
 *  \param none
 *
 *  Prints the heap statistics upon process exit.  Registered
 *  via atexit()
 *
 *  \return none
 */
void printStatistics(void) {
  printf("\nheap management statistics\n");
  printf("mallocs:\t%d\n", num_mallocs);
  printf("frees:\t\t%d\n", num_frees);
  printf("reuses:\t\t%d\n", num_reuses);
  printf("grows:\t\t%d\n", num_grows);
  printf("splits:\t\t%d\n", num_splits);
  printf("coalesces:\t%d\n", num_coalesces);
  printf("blocks:\t\t%d\n", num_blocks);
  printf("requested:\t%d\n", num_requested);
  printf("max heap:\t%d\n", max_heap);
  printf("\nreallocs:\t%d\n", num_reallocs);
  printf("callocs:\t%d\n", num_callocs);
}

struct block {
  size_t size;        /* Size of the allocated block of memory in bytes */
  struct block *next; /* Pointer to the next block of allcated memory   */
  bool free;          /* Is this block free?                     */
};

struct block *FreeList = NULL; /* Free list to track the blocks available */

/*
 * \brief findFreeBlock
 *
 * \param last pointer to the linked list of free blocks
 * \param size size of the block needed in bytes
 *
 * \return a block that fits the request or NULL if no free block matches
 *
 * \TODO Implement Next Fit
 * \TODO Implement Best Fit
 * \TODO Implement Worst Fit
 */
struct block *findFreeBlock(struct block **last, size_t size) {
  struct block *curr = FreeList;

#if defined FIT && FIT == 0
  /* First fit */
  while (curr && !(curr->free && curr->size >= size)) {
    *last = curr;
    curr = curr->next;
  }
#endif

#if defined BEST && BEST == 0
  while (curr && !(curr->free && curr->size >= size)) {
    *last = curr;
    curr = curr->next;
  }

    if (curr) {
        struct block *lastIt = curr;
        struct block *it = curr->next;

        while(it) {
            if ((it->free) && (it->size >= size)) {
                if ((it->size) < (curr->size)) {
                    curr = it;
                    *last = lastIt;
                }
            }
            lastIt = it;
            it = it->next;
        }
    }
  //printf("TODO: Implement best fit here\n");
#endif

#if defined WORST && WORST == 0
  while (curr && !(curr->free && curr->size >= size)) {
    *last = curr;
    curr = curr->next;
  }

    if (curr) {
        struct block *lastIt = curr;
        struct block *it = curr->next;

        while(it) {
            if ((it->free) && (it->size >= curr->size)) {
                    curr = it;
                    *last = lastIt;
            }
            lastIt = it;
            it = it->next;
        }
    }    
   //printf("TODO: Implement worst fit here\n");
#endif

#if defined NEXT && NEXT == 0
    static struct block *old = NULL;

    if (old) {
        if (old->free == false || old->size == 0)
            old = FreeList;
    }

    struct block *it = old ? old->next : FreeList;
    while (it && !(it->free && it->size >= size)) {
        *last = it;
        it = it->next;
    }

    if (it == NULL && old != FreeList) {
        it = FreeList;
        while (it != old && !(it->free && it->size >= size)) {
            *last = it;
            it = it->next;
            if (it == NULL)
                break;
        }
    }

    if (it && it != old) {
        curr = it;
        old = curr;
    } else {
        curr = NULL;
    }

  //printf("TODO: Implement next fit here\n");
#endif
/*
    if (curr && curr->free == false) {
        printf("error: found used block instead of free one.\n");
        assert(1);
    }

    if (curr && *last) {
        if ((*last)->next != curr) {
            printf("error: found last and next block does not match.\n");
            assert(1);
        }
    }
*/
    return curr;
}

/*
 * \brief growheap
 *
 * Given a requested size of memory, use sbrk() to dynamically
 * increase the data segment of the calling process.  Updates
 * the free list with the newly allocated memory.
 *
 * \param last tail of the free block list
 * \param size size in bytes to request from the OS
 *
 * \return returns the newly allocated block of NULL if failed
 */
struct block *growHeap(struct block *last, size_t size) {
  /* Request more space from OS */
  struct block *curr = (struct block *)sbrk(0);
  struct block *prev = (struct block *)sbrk(sizeof(struct block) + size);

  assert(curr == prev);

  /* OS allocation failed */
  if (curr == (struct block *)-1) {
    return NULL;
  }

  /* Update FreeList if not set */
  if (FreeList == NULL) {
    FreeList = curr;
  }

  /* Attach new block to prev block */
  if (last) {
    last->next = curr;
  }

  /* Update block metadata */
  curr->size = size;
  curr->next = NULL;
  curr->free = false;

  num_grows++;
  num_blocks++;
  max_heap += size;
  return curr;
}

void *calloc(size_t nmemb, size_t size) {
    if (nmemb == 0 || size == 0)
        return NULL;

    size_t bytes = nmemb * size;
    void *ptr = malloc(bytes);
    if (ptr == NULL)
        return NULL;

    num_callocs++;
    memset(ptr, 0, bytes);
    return ptr;
}

void *realloc(void* ptr, size_t size) {
    if (!ptr)
        return malloc(size);

    num_reallocs++;
    struct block *curr = BLOCK_HEADER(ptr);
    struct block *nextBlock = curr->next;
    size_t newLength = size - curr->size;
    // in case if next block availble, just split and reuse it
    if (nextBlock && nextBlock->free) {
        if (nextBlock->size >= (newLength + sizeof(struct block))) {
            struct block *newBlock =
              (struct block *)((char *)nextBlock + newLength + sizeof(struct block));
            newBlock->size = newBlock->size - newLength - sizeof(struct block);
            newBlock->next = newBlock->next;
            newBlock->free = true;

            curr->next = newBlock;
            curr->size = size;
            num_reuses++;
            num_splits++;
            return curr;
        }
    }

    void *newPtr = malloc(size);
    if (newPtr == NULL)
        return NULL;
    memcpy(newPtr, ptr, curr->size);
    free(ptr);
    return newPtr;
}

/*
 * \brief malloc
 *
 * finds a free block of heap memory for the calling process.
 * if there is no free block that satisfies the request then grows the
 * heap and returns a new block
 *
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process
 * or NULL if failed
 */
void *malloc(size_t size) {

  if (atexit_registered == 0) {
    atexit_registered = 1;
    atexit(printStatistics);
  }

  /* Align to multiple of 4 */
  size = ALIGN4(size);

  /* Handle 0 size */
  if (size == 0) {
    return NULL;
  }

  /* Look for free block */
  struct block *last = FreeList;
  struct block *next = findFreeBlock(&last, size);

  /* TODO: Split free block if possible */
  if (next) {
    if ((next->size) >= (size + sizeof(struct block))) {
      // split block
      struct block *newBlock =
          (struct block *)((char *)next + size + sizeof(struct block));
      newBlock->size = next->size - size - sizeof(struct block);
      newBlock->next = next->next;
      newBlock->free = true;

      next->size = size;
      next->next = newBlock;

      num_splits++;
      num_blocks++;
    }
    num_reuses++;
  }

  /* Could not find free block, so grow heap */
  if (next == NULL) {
    next = growHeap(last, size);
  }

  /* Could not find free block or grow heap, so just return NULL */
  if (next == NULL) {
    return NULL;
  }

  /* Mark block as in use */
  next->free = false;
  num_mallocs++;
  num_requested += size;
  /* Return data address associated with block */
  return BLOCK_DATA(next);
}

/*
 * \brief free
 *
 * frees the memory block pointed to by pointer. if the block is adjacent
 * to another block then coalesces (combines) them
 *
 * \param ptr the heap memory to free
 *
 * \return none
 */
void free(void *ptr) {
  if (ptr == NULL) {
    return;
  }

  /* Make block as free */
  struct block *curr = BLOCK_HEADER(ptr);
  assert(curr->free == 0);
  curr->free = true;
  num_frees++;
  /* TODO: Coalesce free blocks if needed */

  struct block *nextBlock = curr->next;
  // right Coalesce
  if (nextBlock && nextBlock->free) {
    curr->next = nextBlock->next;
    curr->size += nextBlock->size + sizeof(struct block);
    nextBlock->size = 0; //this will be used to detect invalid pointer in next-fit
    num_coalesces++;
    num_blocks--;
  }

  // left Coalesce
  struct block *it = FreeList;
  while (it && !(it->free && it->next == curr)) {
    it = it->next;
  }

  if (it) {
    it->next = curr->next;
    it->size += curr->size + sizeof(struct block);
    curr->size = 0; //this will be used to detect invalid pointer in next-fit
    num_coalesces++;
    num_blocks--;
  }
}

/* vim: set expandtab sts=3 sw=3 ts=6 ft=cpp: --------------------------------*/
